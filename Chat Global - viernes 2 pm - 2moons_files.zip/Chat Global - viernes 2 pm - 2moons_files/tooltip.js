
$(document).ready(function () {
    //fleet speed, incoming attacks
    $(document).on("mouseenter", ".tooltip", function (e) {
        var tip = $('#tooltip');
        tip.html($(this).attr('data-tooltip-content'));
        tip.show();
    });
    $(document).on("mouseleave", ".tooltip", function () {
        var tip = $('#tooltip');
        tip.hide();
    });
    $(document).on("mousemove", ".tooltip", function (e) {
        var tip = $('#tooltip');
        var mousex = e.pageX + 20;
        var mousey = e.pageY + 20;
        var tipWidth = tip.width();
        var tipHeight = tip.height();
        var tipVisX = $(window).width() - (mousex + tipWidth);
        var tipVisY = $(window).height() - (mousey + tipHeight);
        if (tipVisX < 20) {
            mousex = e.pageX - tipWidth - 20;
        }

        if (tipVisY < 20) {
            mousey = e.pageY - tipHeight - 20;
        }

        tip.css({
            top: mousey,
            left: mousex
        });
    });

    // galaxy, buildings, hangar, defenses
    $(document).on('mouseenter', ".tooltip_sticky", function (e) {
        var tip = $('#tooltip');
        tip.html($(this).attr('data-tooltip-content'));
        tip.addClass('tooltip_sticky_div');
        tip.css({
            top: e.pageY - tip.outerHeight() / 2,
            left: e.pageX - tip.outerWidth() / 2
        });
        tip.show();
    });
    $(document).on('mouseleave', ".tooltip_sticky_div", function () {
        var tip = $('#tooltip');
        tip.removeClass('tooltip_sticky_div');
        tip.hide();
    });

    // ???
    $(document).on('submit', ".tooltip_sticky1", function (e) {
        var tip = $('#tooltip');
        tip.html($(this).attr('data-tooltip-content'));
        tip.addClass('tooltip_sticky_div1');
        tip.css({
            top: e.pageY - tip.outerHeight() / 2,
            left: (e.pageX - tip.outerWidth() / 2) + 180
        });
        tip.show();
    });
    $(document).on('mouseleave', ".tooltip_sticky_div1", function () {
        var tip = $('#tooltip');
        tip.removeClass('tooltip_sticky_div1');
        tip.hide();
    });
});